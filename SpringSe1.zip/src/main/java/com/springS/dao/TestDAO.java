package com.springS.dao;

public interface TestDAO {

		int insertTest();
		int deleteTest();
}
