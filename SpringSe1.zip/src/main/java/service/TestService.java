package service;

public interface TestService {

	int insertTest();
	int deleteTest();
}
